from setuptools import setup

setup(name='pyprob_distributions',
      version='0.1',
      description='Gaussian and Binominal distributions',
      packages=['pyprob_distributions'],
      author = 'Adithya Yelloju',
      author_email = 'adithyayelloju@gmail.com',
      zip_safe=False)
